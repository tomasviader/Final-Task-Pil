package com.example.FinalPil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalPilApplicationTests {

	@Test
	void contextLoads() {
	}

}
